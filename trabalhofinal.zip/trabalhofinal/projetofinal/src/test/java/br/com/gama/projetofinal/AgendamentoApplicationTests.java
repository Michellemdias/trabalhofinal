package br.com.gama.projetofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
