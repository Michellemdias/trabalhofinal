package br.com.gama.projetofinal.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.gama.projetofinal.model.Agencia;

public interface AgenciaDAO extends CrudRepository<Agencia, Integer>{

}
